package d_day;

public class D_Day_List {
   private int member_id; //pk
   private int dday_id;
   private String d_name;
   private int d_year;
   private int d_month;
   private int d_day;
   public int getMember_id() {
      return member_id;
   }
   public void setMember_id(int member_id) {
      this.member_id = member_id;
   }
   public int getDday_id() {
      return dday_id;
   }
   public void setDday_id(int dday_id) {
      this.dday_id = dday_id;
   }
   public String getD_name() {
      return d_name;
   }
   public void setD_name(String d_name) {
      this.d_name = d_name;
   }
   public int getD_year() {
      return d_year;
   }
   public void setD_year(int d_year) {
      this.d_year = d_year;
   }
   public int getD_month() {
      return d_month;
   }
   public void setD_month(int d_month) {
      this.d_month = d_month;
   }
   public int getD_day() {
      return d_day;
   }
   public void setD_day(int d_day) {
      this.d_day = d_day;
   }
   
   
}