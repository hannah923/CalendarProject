package member;

public class CalendarMember {
   private int member_id; //pk
   private String m_id;
   private String m_pw;
   private String m_nickName;
   private String m_email;
   private String m_phone;
   
   public int getMember_id() {
      return member_id;
   }
   public void setMember_id(int member_id) {
      this.member_id = member_id;
   }
   public String getM_id() {
      return m_id;
   }
   public void setM_id(String m_id) {
      this.m_id = m_id;
   }
   public String getM_pw() {
      return m_pw;
   }
   public void setM_pw(String m_pw) {
      this.m_pw = m_pw;
   }
   public String getM_nickName() {
      return m_nickName;
   }
   public void setM_nickName(String m_nickName) {
      this.m_nickName = m_nickName;
   }
   public String getM_email() {
      return m_email;
   }
   public void setM_email(String m_email) {
      this.m_email = m_email;
   }
   public String getM_phone() {
      return m_phone;
   }
   public void setM_phone(String m_phone) {
      this.m_phone = m_phone;
   }
   
   
}